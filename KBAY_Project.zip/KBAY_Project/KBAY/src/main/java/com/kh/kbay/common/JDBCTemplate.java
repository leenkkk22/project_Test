package com.kh.kbay.common;

public class JDBCTemplate {

}
